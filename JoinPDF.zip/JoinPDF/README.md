
Click the link below to see this automation in action.

https://youtu.be/XkGGOJz8KfA

You can use this automation to join/merge PDF documents!
